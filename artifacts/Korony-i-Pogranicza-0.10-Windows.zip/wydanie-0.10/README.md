# Korony i Pogranicza · 0.10

Autorska, jednoosobowa strategia turowa dla Windows, napisana w **C# / .NET 10**, z interfejsem i dialogami po polsku. Historycznie inspirowany świat jest fikcyjny. Gracz prowadzi Marchie Veyru od osadnictwa po odkrycia naukowe i instytucje nowoczesnego państwa.

To **grywalna wersja rozwojowa**, a nie ukończona produkcja o skali komercyjnej Cywilizacji. Fundamentem wyróżniającym projekt są pamięć polityczna państwa, stronnictwa społeczne i konsekwencje dialogów. Zmiana epoki nie usuwa miast ani historii.

## Uruchomienie

Uruchom `wydanie-0.10/KoronyIPogranicza.exe` albo główny `Uruchom.cmd`. Zachowaj pozostałe pliki z katalogu `wydanie-0.10` obok programu. Poprzednie wydania pozostają w osobnych katalogach.

**Nowy etap: Otwarte bramy.** Wersja 0.10 dodaje negocjowane zgody na tranzyt i raport państw zamykających potencjalny szlak. Możesz oprzeć prośbę na zaufaniu albo zaoferować opłatę. Dwuturowa podróż posłów i termin wygaśnięcia zgody wpływają na los już opłaconych transportów. Szczegóły: `CHANGELOG.md`.

Wymagania: Windows 10/11 i **.NET Desktop Runtime 10 x64**. Na komputerze, na którym powstał projekt, ten runtime jest zainstalowany. Wydanie korzysta z zainstalowanego środowiska .NET, nie zawiera własnego runtime'u. Gra nie wymaga połączenia z Internetem ani konta.

## Co jest grywalne

- Świat 42 × 28 heksów: ziarno proceduralne, biomy, rzeki, zasoby, ruiny, mgła wojny, przybliżanie i minimapa. Stolice mają gwarantowane połączenie lądowe.
- Cztery fikcyjne państwa z różnymi premiami; gracz prowadzi jedno, trzy obsługuje AI. Trzy poziomy trudności zmieniają wydajność AI.
- Miasta, ludność, wzrost i głód, sezonowe plony, eksploatacja pól, farmy, kopalnie, placówki handlowe, produkcja i utrzymanie.
- 24 technologie z wymaganiami; 18 trwałych projektów miejskich, dwa projekty powtarzalne i sześć rodzajów oddziałów.
- Lud, rody i uczeni: ich poparcie wpływa na docelową stabilność, a ta na gospodarkę. Ustawy zmieniają podatki, ustrój i priorytety.
- 25 rodzajów wyjątkowych i kontekstowych spraw rady oraz cztery wydarzenia powracające. Sprawy prowincji mogą pojawiać się osobno dla każdego miasta; delegacje kupców odnoszą się do konkretnych utraconych karawan. Odpowiedzi zmieniają poparcie, prawa lokalne i przyszłe zdarzenia. Nadanie ziemi lub przywilejów zmienia późniejszą gałąź dialogów. Prawo traktu trwale zmienia dochody, naukę albo dostawy.
- Dyplomacja: dary, handel, krzywdy, trzy powody wypowiedzenia wojny, odszkodowania, pakty o nieagresji i rozejmy. Posłowie wracają z odpowiedzią po dwóch turach. AI zakłada miasta, bada, buduje, ulepsza ziemię i prowadzi działania wojenne.
- Negocjowany pokój z reparacjami i zwrotem miast, propozycjami AI, kontrofertami i terminem odpowiedzi. Historia wojny przechowuje ogłoszony cel, straty, bilans i końcowe rozliczenie obietnicy.
- Walka wręcz i dystansowa, doświadczenie, obrona terenu, oblężenia i przejmowanie miast. Woda i góry blokują ruch. Armie poza zasięgiem dostaw słabną; odpoczynek leczy.
- Drogi za 25 złota i 0,15 złota utrzymania/turę, automatyczna wycena połączeń miast, premie handlowe, blokowanie dostaw przez wojska i niszczenie wrogich dróg. Ruch między połączonymi odcinkami kosztuje 0,5 punktu.
- Rozkazy marszu zapisywane między turami i w plikach kampanii; podświetlenie zasięgu i trasy. Atak wymaga potwierdzenia podglądu zgodnego z modelem walki.
- Prowincje z własnymi potrzebami, kierunkiem rozwoju i dobrobytem. Dzielnice mieszkalne oraz lecznice ograniczają presję społeczną. Regionalna wymiana karmi miasta z niedoborem, a bezpieczne drogi umożliwiają przeprowadzki do lepszych warunków.
- Lojalność i pamięć założycieli miast. Autonomia oddaje część dochodów za większą lojalność i kulturę; zarząd wojskowy wymaga garnizonu. Podbite miasto może wrócić do założycieli po trzech turach lojalności poniżej 20.
- Fizyczne zapasy żelaza, soli i barwników, wydobycie z pracujących pól, regionalny popyt i ceny. Dostawy krajowe dzielą nadwyżkę w sieci drogowej. Kontrakty zagraniczne przenoszą towary i złoto; embargo, wojna i blokady przerywają dostawy.
- Karawany poruszające się po heksach, podgląd trasy i czasu przybycia, tranzyt przez państwa trzecie, przechwytywanie przez wroga i osłona przez pobliskie wojska. Nabywca płaci przy wysyłce i ponosi ryzyko utraty.
- Delegacje kupieckie po stratach importów, pomoc zależna od wartości manifestu i obietnice zastępczych dostaw do wskazanego miasta. Termin, postęp, manifesty i polityczny wynik pozostają w historii kampanii.
- Wyznaczone eskorty karawan: wspólny marsz, koszt pozostałego ruchu, rezerwacja oddziału, brak odpoczynku i zakończenie przy niedostępnej wojskowo granicy. Zwiadowcy AI mogą objąć eskortę na polu własnego transportu.
- Zwycięstwo naukowe, kulturowe, przez zjednoczenie oraz punktowe po 320 turach. Kampania może zakończyć się wcześniej.
- Zapis i wczytanie stanu JSON z walidacją, atomowym zastępowaniem pliku i zapisanym stanem generatora losowego. Autozapis po turze i decyzji rady; kronika przechowuje wybory oraz ich skutki.

Długość i balans wymagają dalszych rozgrywek z udziałem człowieka. Automatyczne symulacje nie potwierdzają jakości wielogodzinnej rozgrywki.

## Poselstwa o prawo przejazdu

**Granice i tranzyt** w raporcie karawany lub **Sprawdź granice wybranej trasy** w formularzu kontraktu wskazuje brakujące zgody na jednym potencjalnym bezpiecznym korytarzu. Dostępny neutralny objazd wyklucza zgłoszenie blokady granic. Jeśli droga wymaga kilku państw, każde musi wyrazić własną zgodę. Raport nie proponuje poselstwa jako sposobu obejścia wojny, embarga, gór lub okupacji przez wrogie wojsko.

W **Dyplomacja → Przejazd kupców** wybierz prośbę o bezpłatny tranzyt albo jednorazową opłatę 60 złota. Podróż posłów kosztuje zawsze 20 złota i trwa dwie tury. Ocena to zaufanie +10 za traktat z gospodarzem +35 za ofertę opłaty -15 wobec Kharu; przyjęcie wymaga 15. Nie ma losowania. Sytuację i środki sprawdzamy ponownie w dniu odpowiedzi. Opłata 60 złota przechodzi do gospodarza dopiero po przyjęciu; jeśli ją wcześniej wydasz, propozycja zostanie odrzucona. Przyjęcie daje relacje +5, odmowa -5. Obowiązuje wspólna dla wszystkich poselstw przerwa dziesięciu tur i jedna rozmowa z danym państwem na turę.

Zgoda działa przez 12 faz rynku od tury przyjęcia, także dla już wysłanych ładunków oraz rozwiązanych lub wygasłych kontraktów. Zastępuje wyłącznie wymóg traktatów gospodarza z obiema stronami transportu. Traktat między kupującym i sprzedawcą nadal jest konieczny. Zgoda nie obejmuje transportów między samymi państwami AI ani przemarszu wojska. Wojna z którąkolwiek stroną i embargo zawieszają przejazd; po ich ustaniu pozostały czas zgody może zostać wykorzystany.

Zgoda przyjęta w T5 pozwala przejeżdżać w fazach T5–T16 i wygasa przed rynkiem T17. Na dwie tury przed końcem oraz w dniu wygaśnięcia pojawia się wpis kroniki i komunikat przy zmianie tury, o ile pierwszeństwa nie mają pilniejsze wieści. Aktywnej zgody nie można przedłużyć z góry; po wygaśnięciu można wysłać nowe poselstwo. Eskorta zatrzyma się przed wojskowo niedostępną granicą. Zablokowana karawana nadal przepada przy trzecim kolejnym postoju, również wewnątrz obcego kraju. Poselstwo nie zatrzymuje tego licznika i może wrócić za późno; utraconego manifestu nie przywraca.

## Pierwsze dziesięć tur

1. Rozpocznij nową historię i odpowiedz kanclerce w sali rady. Każda opcja pokazuje pełne zmiany liczbowe oraz przyszłe skutki.
2. Wybierz zwiadowcę LPM. Wskaż PPM pobliskie odkryte pole, aby przesunąć oddział i odsłonić kolejne ziemie. Ruiny dają złoto, naukę i prestiż.
3. Odkryj Rolnictwo. W Wysogrodzie wybierz spichlerz, a potem osadników. Rekrutacja wymaga co najmniej trzech mieszkańców i zużywa jednego.
4. Miasto można założyć na lądzie co najmniej cztery pola od innych miast. Wybierz osadników i przycisk założenia miasta w panelu.
5. Własne pola możesz ulepszać za złoto. Miasto wykorzystuje najlepsze pola w promieniu dwóch heksów, do limitu zależnego od ludności. Ulepszenie odległego, niepracującego pola nie daje dochodu.
6. Zachowaj rezerwę skarbu. Biblioteki podnoszą naukę, traktaty dają dochód, a nadmierna armia i wysokie podatki mają koszty społeczne.
7. Po Garncarstwie buduj drogi na własnej lub neutralnej ziemi. Panel „Szlaki” wycenia całe połączenie ze stolicą i pokazuje przychody oraz koszty utrzymania. Bezpiecznie połączone prowincje mają premię do bazowego złota i nauki.

## Dostawy i rozkazy

Każde własne miasto wysyła dostawy. Liczy się koszt dostępnej trasy, a nie odległość w linii prostej: zwykły ląd kosztuje 1, lasy, wzgórza i mokradła 2, a połączone drogi 0,5. Zima podnosi koszt poza drogami o 25%; na obcej ziemi transport kosztuje dodatkowe 0,5. Podstawowy zasięg kosztowy to 6; Szlaki handlowe i Inżynieria zwiększają go po 2. Wybrane patrole rady mogą dodać jeszcze 1.

Wrogie oddziały bojowe blokują własne pole i sąsiedztwo. Własne wojska bojowe osłaniają zajmowany heks przed sąsiednią strefą przeciwnika. Droga odcięta przez wroga nie daje premii połączenia miasta. Bez dostaw siła spada do 72%, a armie tracą 5 zdrowia/turę; zwiadowcy i osadnicy nie ponoszą strat marszowych. Włącz przycisk „Dostawy”, aby zobaczyć obszary zaopatrzenia i blokady.

PPM na odkrytym, odległym polu wydaje rozkaz marszu. Oddział wykona dostępny odcinek teraz i będzie szedł dalej po następnych turach. Przy zmianie granic lub blokadzie może znaleźć inną dostępną trasę; jeśli żadna nie istnieje, przerwie marsz. Samodzielnie nie atakuje. Rozkaz można anulować w panelu oddziału. PPM na przeciwniku otwiera podgląd starcia; dopiero „Wykonaj atak” zużywa ruch i rozstrzyga walkę.

## Życie prowincji

Panel **Ludność** pokazuje potrzeby i migracje, a **Zarządzaj** otwiera działania dla konkretnego miasta. W widoku miasta przycisk „Mieszkańcy” prowadzi do tego samego okna.

- Miejsca mieszkalne: początkowo 6; dzielnica mieszkalna +5, akwedukt +2, służba publiczna +2, parlament +3. Miejscowe prawa mogą dodać kolejne 2.
- Pojemność opieki: początkowo 6; rzeka +1, akwedukt +4, lecznica +6, medycyna +3. Priorytet rzemiosła obniża ją o 1.
- Kierunek rozwoju kosztuje 15 złota, zmienia się raz na turę: rolnictwo +20% żywności i -10% produkcji; rzemiosło +20% produkcji i -10% żywności; nauka +25% nauki i -10% złota. Równowaga nie ma tych modyfikatorów.
- Pomoc kosztuje 50 złota: +25 zapasów żywności, -8 niepokojów i +4 dobrobytu, raz na pięć tur w danym mieście.

Połączone bezpiecznymi drogami miasta tworzą regionalne rynki, także bez połączenia ze stolicą. Nadwyżka żywności po wyżywieniu mieszkańców może być eksportowana do miasta z deficytem: maksymalnie 6 na miasto i turę w każdą stronę. Najpilniejsze niedobory mają pierwszeństwo. Eksport zmniejsza żywność pozostającą na wzrost, import nie tworzy nowej żywności. Blokada przerywa wymianę. Sól i barwniki z zasobów oraz magazynów są widoczne jako dostęp regionu do towaru; wpływ na dobrobyt wynika teraz z rzeczywistego zużycia. Sam traktat i targowisko nie przyznają już automatycznych towarów zagranicznych.

Przeludnienie, niedostateczna opieka i brak żywności zwiększają niepokoje i obniżają docelowy dobrobyt. Dobrobyt zbliża się do celu o maksymalnie 2 punkty na turę i zmienia wydajność produkcji, nauki, złota i kultury w przedziale 90–110%. Pierwsza tura głodu powoduje niepokoje; co druga kolejna tura z pustymi zapasami i niedoborem odbiera mieszkańca.

Migracje wewnątrz państwa są sprawdzane co cztery tury. Miasto źródłowe musi mieć co najmniej trzech mieszkańców i problemy lokalne. Cel musi leżeć w tej samej bezpiecznej sieci, mieć wolne mieszkania i opiekę, nadwyżkę żywności co najmniej 2 oraz dobrobyt wyższy o przynajmniej 10. Przenosi się jeden mieszkaniec; liczba ludności pozostaje stała. Dane miasto uczestniczy ponownie najwcześniej po ośmiu turach. Napływ zwiększa niepokoje o 4, chyba że przyjęto prawo integracji.

Głód, brak mieszkań i napływ ludności wywołują sprawy rady przypisane do wskazanego miasta. Każda taka sprawa jest rozstrzygana raz na prowincję, z odstępem co najmniej 15 tur między sprawami. Lokalne prawa pozostają przy mieście i są widoczne w jego panelu. Nie ma symulacji indywidualnych gospodarstw; ceny obejmują trzy towary opisane poniżej.

## Rynki, ceny i kontrakty

Panel **Rynek** pokazuje prognozę zapasów, produkcji, popytu i cen. **Bilans towarów** rozpisuje każdą jednostkę: zapas początkowy + produkcja + import krajowy i zagraniczny - eksport - zużycie - utrata = zapas końcowy. Żywność nadal ma odrębne spichlerze i system przesyłek.

| Towar | Popyt na turę | Skutek zużycia |
|---|---|---|
| Żelazo | 0,15 × mieszkańcy, +1 za warsztat, +2 za fabrykę | Mnożnik produkcji od 0,90 przy braku do 1,00 przy pełnym zaspokojeniu |
| Sól | 0,35 × mieszkańcy | Wraz z barwnikami zmienia cel dobrobytu |
| Barwniki | 0,20 × mieszkańcy, +1 za dom bankierski | Wraz z solą zmienia cel dobrobytu |

Wpływ obu dóbr na docelowy dobrobyt wynosi `zaokrąglij(6 × (pokrycie soli + pokrycie barwników)) - 4`, czyli od -4 do +8. Nie zmienia dobrobytu natychmiast: ten nadal zbliża się do celu o maksymalnie 2 punkty na turę. Żelazo z magazynów nie zastępuje warunków surowcowych dotychczasowych premii bojowych.

Pracujące własne pole żelaza, soli lub barwników produkuje 2 jednostki towaru na turę. Kopalnia dodaje 2 dla żelaza, placówka handlowa 1 dla towaru. Pole współdzielone przez zasięgi miast przypada tylko jednemu pracującemu miastu, z pierwszeństwem najbliższego, potem starszego. Nie produkuje pod blokadą. Nie ma jeszcze wyczerpywania złóż.

Miasto mieści 50 jednostek każdego towaru; targowisko dodaje 25, **Skład towarowy** kolejne 100. Skład kosztuje 150 produkcji i wymaga technologii **Moneta**. Nadmiar po zużyciu przepada i jest wykazany w bilansie. Zajęcie miasta przejmuje jego zapasy, a stare raporty podatkowe są zerowane.

Miasta jednej bezpiecznej sieci drogowej mają wspólną cenę. Bazy to 8 złota dla żelaza, 5 dla soli i 9 dla barwników. Cena wynika z `baza × (0,75 + popyt / (zapasy + nowa produkcja + przybyłe ładunki + 1))`, z limitem trzykrotnej bazy i zaokrągleniem do dwóch miejsc. Obliczana jest po przybyciu karawan, przed nowymi załadunkami i zużyciem. Wymiana krajowa najpierw pokrywa potrzeby z własnych zapasów miasta, następnie z nadwyżek połączonych miast.

W **Podpisz kontrakt handlowy** wybierz import lub eksport, miasta, towar i limit 1–6 jednostek na karawanę. Umowa kosztuje 15 złota i obowiązuje do rozliczenia tury początkowej +12. Limit to trzy aktywne umowy na każde państwo i jedna karawana w drodze na umowę. Wymagane są targowiska i Szlaki handlowe po obu stronach, pokojowy traktat, bezpieczne połączenie każdego miasta ze swoją stolicą oraz dostępna trasa lądowa.

Cena kontraktowa wynosi 115% ceny regionalnej sprzedawcy. Przy załadunku zależy od aktualnego rynku; podpis nie blokuje ceny, zapasu ani złota. Ładunek może być częściowy z powodu braku towarów lub funduszy. Nabywca płaci przy wysyłce bezpośrednio sprzedawcy, bez mnożników trudności. Towar opuszcza magazyny sprzedawcy i pozostaje w transporcie aż do przybycia; import w bilansie odbiorcy oznacza dopiero faktyczny przyjazd. Umowy rozliczane są w kolejności podpisania.

### Karawany i ochrona dróg

Panel **Rynek → Karawany i trasy** pokazuje manifesty, zapłacone kwoty, pozycje, pozostały czas podróży i przyczyny postoju. **Pokaż na mapie** centruje kamerę i zaznacza pozostałą trasę na odkrytych heksach. Znacznik wozu oznacza karawanę; pomarańczowy kolor — postój. Można zakończyć śledzenie przyciskiem w panelu rynku. Kliknięcie pola z własnym transportem pozwala otworzyć raport także z panelu terenu.

Karawana otrzymuje 3 punkty ruchu na fazę rynku. Połączone drogi kosztują 0,5, lasy, wzgórza i mokradła 2, pozostały ląd 1. Niewykorzystane punkty nie przechodzą między turami. Załadowany transport zaczyna marsz przy następnym rozliczeniu. Podany czas jest prognozą według obecnej trasy, bez przyszłych blokad; transport nie używa sezonowych modyfikatorów dostaw wojskowych.

Szlak biegnie przez ziemie obu stron i neutralny ląd. Przejazd przez trzecie państwo wymaga jego pokojowych traktatów handlowych z obiema stronami albo czasowej zgody na przewóz ładunków Marchii. Gospodarz musi pozostawać w pokoju z obiema stronami i nie stosować embarga. Zmiany dróg, granic i wojsk powodują ponowne wyszukiwanie najtańszej bezpiecznej trasy, bez teleportowania ładunku.

Wrogie wobec którejkolwiek ze stron oddziały państwa trzeciego stwarzają zagrożenie na swoim polu i w sąsiedztwie. Oddział nabywcy albo sprzedawcy (również zwiadowca, bez osadników) w promieniu jednego pola osłania przed sąsiednią strefą zagrożenia; miasto stron osłania własne pole. Wrogi oddział bezpośrednio na heksie transportu przechwytuje go zawsze. Karawana omija nieosłonięte zagrożenia; jeśli przeciwnik podejdzie do jej obecnej pozycji, przed końcem tury trzeba zapewnić osłonę lub usunąć przeciwnika. Wyznaczona eskorta może teraz podążać razem z transportem. Nie ma osobnej komendy ataku na wóz.

### Rozkaz eskorty

1. W **Rynek → Karawany i trasy** wybierz **Pokaż na mapie** i przesuń własny oddział na pole aktywnego wozu. Eskorta nie zbiera się sama ani nie ściga karawany z odległej pozycji.
2. W raporcie wybierz **Wyznacz eskortę**, a następnie gotowy oddział. Ten sam rozkaz można wydać z panelu jednostki stojącej na polu wozu. Potrzebne jest co najmniej 0,5 pozostałego punktu ruchu. Osadnicy są wykluczeni; jedna karawana może mieć jeden wyznaczony oddział, należący do strony umowy.
3. Przy kolejnym rozliczeniu rynku oddział i wóz ruszą razem. Rozkaz zastępuje wcześniejszy marsz, ale jego przyjęcie nie przesuwa wojska i nie pobiera złota. Zwykłe utrzymanie armii działa dalej.

Wspólny ruch zużywa pozostałe punkty oddziału oraz budżet 3 punktów karawany. Włócznicy mają 2 punkty, więc na zwykłym lądzie przejdą z wozem do dwóch heksów, a po połączonej drodze do czterech. Zwiadowcy i kawaleria mają 3 punkty. Brak punktów na kolejny heks powoduje postój; następna tura przywraca zwykły budżet wojska. Niewykorzystany ruch nie przechodzi między turami. Trzy kolejne pełne fazy postoju nadal oznaczają utratę ładunku.

Eskorta nie wykonuje samodzielnego marszu, ataku ani niszczenia dróg i nie korzysta z biernego leczenia podczas służby. Aby użyć oddziału inaczej, wybierz **Odwołaj eskortę** w raporcie lub panelu jednostki. Wydane punkty nie wracają. Dostawy wojskowe i straty z ich braku działają normalnie. Ruch eskorty odsłania teren i może zbadać mijane ruiny; prognoza nie przyznaje za nie nagród.

Traktat handlowy **nie daje prawa przejścia armii**. Gdy kolejne pole jest niedostępne wojskowo — np. pokojowe obce terytorium, obce miasto albo pole obcego oddziału — eskorta kończy się na ostatnim osiągniętym heksie. Wóz ponownie ocenia dalszą trasę bez ruchomej osłony i może kontynuować samotnie lub czekać. Oddział nie wraca automatycznie do stolicy. Algorytm wybiera trasę karawany; nie szuka osobnego wojskowego objazdu dla zachowania eskorty. Raport ostrzega o przewidywanym odłączeniu. Szacowany czas uwzględnia ruch oddziału na bieżącej trasie; po odłączeniu i zmianie bezpieczeństwa może się zmienić.

Eskorta utrzymuje istniejącą ochronę przed sąsiednią strefą zagrożenia. Nie rozgrywa automatycznej bitwy i nie daje odporności na bezpośrednie zajęcie pola wozu przez wroga. Przybycie, utrata transportu albo odłączenie oddziału kończą rozkaz. Ewakuacja po zdobyciu miasta również usuwa nieaktualny przydział. Kolejna karawana tej samej umowy wymaga nowego rozkazu.

Raport pokazuje nazwę i państwo oddziału, pozostały ruch oraz prognozę. Na mapie litera **E** oznacza wyznaczoną eskortę. AI może przydzielić własnego, zdrowego zwiadowcę stojącego na polu transportu swojej strony umowy i zachowuje go przy wozie; nie przejmuje rozkazów gracza. Nie planuje jeszcze złożonych marszów na miejsce zbiórki ani obrony całej sieci drogowej.

Embargo, wojna między stronami i zerwany traktat zatrzymują wysłany transport. Brak dostępnej trasy także powoduje postój. **Trzy kolejne fazy postoju oznaczają utratę całego ładunku bez zwrotu zapłaty**; wznowienie marszu zeruje licznik. Zmiana właściciela któregokolwiek miasta umowy oznacza utratę przy następnym rozliczeniu. Zdarzenia są zapisywane w kronice, a interfejs zgłasza kłopoty na szlaku. Nie ma losowych rozbójników ani ubezpieczenia; przechwycenie wynika ze stanu mapy i nie daje napastnikowi nowego złota.

Wygaśnięcie lub dobrowolne rozwiązanie umowy zatrzymuje kolejne załadunki. Już opłacone karawany kontynuują podróż i mogą dotrzeć później. Gdy poprzedni transport dotrze albo zostanie utracony, aktywna umowa może wysłać kolejny w tej samej fazie. Długa trasa ogranicza więc częstotliwość zaopatrzenia.

| Polityka | Skutek |
|---|---|
| Najpierw mieszkańcy | Eksport zostawia w regionie zapas równy jednej turze jego popytu |
| Swobodny eksport | Pozwala wywieźć towar przed zaspokojeniem własnych potrzeb |
| Embargo | Wstrzymuje import i eksport, pozostawiając wymianę krajową |

Zmiana polityki kosztuje 30 złota i ma odstęp ośmiu tur. Embargo, wojna, zerwanie traktatu i odcięcie stolicy wstrzymują nowe załadunki, ale czas umowy nadal upływa. Wysłany ładunek stosuje opisane wyżej zasady karawan; nie musi ponownie wracać do sieci stolicy. Zmiana właściciela miasta rozwiązuje umowę przy następnym rozliczeniu. Umowę można samodzielnie rozwiązać w panelu. AI zawiera umowy między własnymi państwami; kontrakty Marchii wymagają działania gracza. Transporty AI podlegają tym samym regułom ruchu i ryzyka.

Zużycie tworzy podatek od obrotu: 8%, 12% lub 18% wartości towarów przy niskich, zwykłych lub wysokich podatkach. Trafia on do dochodu państwa; płatności zagraniczne są księgowane odrębnie, aby nie pobierać ich dwukrotnie. W budżecie i nagłówku podatki rynku są oparte na ostatnim rozliczeniu, a przepływ kontraktów na aktualnej prognozie. Dochód prywatnych gospodarstw pozostaje abstrakcyjny, podobnie jak dotychczasowy dochód miejski.

Sprawa rady **Komu służy otwarty targ?** wiąże politykę handlową z poparciem i skarbem. Wybór embarga obejmuje teraz również już opłacone transporty. Ceny obejmują trzy towary; nie ma samodzielnych przedsiębiorstw kupieckich, frachtu morskiego ani kredytu.

## Kupcy pamiętają: straty i obietnice

Utrata importowej karawany do nadal własnego miasta może otworzyć **Wozy, które nie wróciły**. Delegacja odwołuje się do rzeczywistego manifestu, wartości zakupu, towaru i odbiorcy. Otwarcie sprawy oznacza lud -2 i miejscowe niepokoje +4. Jedno miasto otwiera najwyżej jedną nową sprawę na dziesięć tur, niezależnie od liczby strat. Straty eksportów do obcych odbiorców i straty po przejęciu miasta nie wywołują krajowej delegacji.

W panelu **Rynek → Sprawy kupców i obietnice** można otworzyć oczekującą sprawę, przejrzeć zobowiązania oraz ich wyniki. Delegacja pojawia się też przy najbliższym planowaniu rady, bez czekania na turę podzielną przez pięć. Wcześniejsza sprawa rady musi najpierw otrzymać odpowiedź.

| Odpowiedź | Koszt i bezpośredni skutek |
|---|---|
| Odszkodowanie | Koszt równy zapłaconej wartości utraconego ładunku, zaokrąglonej w górę do pełnego złota; lud +5, rody +2; w mieście dobrobyt +8, niepokoje -6 |
| Obietnica zastępczej dostawy | Lud +2 teraz; trzeba sprowadzić ilość i rodzaj towaru z utraconego manifestu do wskazanego miasta, do fazy rynku tury decyzji +8 włącznie |
| Odmowa pomocy | Bez opłaty; lud -5, rody -4; w mieście niepokoje +8 |

Odszkodowanie jest dodatkową pomocą ze skarbu, nie zwrotem pierwotnej zapłaty od sprzedawcy. Nie odtwarza towarów. Odmowa pozostaje dostępna także przy pustym skarbie. Wszystkie skutki społeczne i miejscowe podlegają zwykłym granicom 0–100.

Obietnicę wypełnia suma **faktycznych zagranicznych przyjazdów po decyzji**, z właściwym towarem i odbiorcą. Można zsumować kilka częściowych dostaw; liczy się również karawana wysłana wcześniej, która dopiero dotrze. Nie liczą się wcześniejsze przyjazdy, samo opłacenie ładunku, własne zapasy, produkcja, wymiana krajowa, inny towar ani inne miasto. Nie można utrzymywać dwóch obietnic tego samego towaru dla jednej prowincji ani rozliczyć tego samego manifestu dwukrotnie. Wygaśnięcie kontraktu nie usuwa obietnicy: liczy się przybycie opłaconego transportu.

- **Dotrzymane słowo:** lud +6, stabilność +2, prestiż +5; w mieście dobrobyt +8 i niepokoje -6.
- **Złamana obietnica:** lud -10, stabilność -4, prestiż -5 (minimum 0); we własnym mieście dobrobyt -6 i niepokoje +10.

Ostatnia dozwolona faza najpierw rozlicza przyjazdy, a dopiero potem ewentualną porażkę. Spóźniona dostawa nie zmienia już wyniku. Utrata miasta zamyka nierozpatrzoną delegację, a podjętą obietnicę łamie; nowy właściciel nie otrzymuje dodatkowej kary miejscowej. Każdy wynik rozlicza się raz i trafia do kroniki. Zapis zachowuje termin oraz identyfikatory zaliczonych ładunków. To rozbudowa jednego wątku kupieckiego; nie ma jeszcze osobnych przedsiębiorstw, dowolnie składanych obietnic ani złożonych osobowości kupców.

## Poselstwa i uzasadnienia wojny

W **Dyplomacji** wybierz **Negocjuj warunki**. Podróż kosztuje 20 złota. Odszkodowanie wymaga co najmniej 30 krzywd; przyjęcie przynosi 80 złota i zużywa 30 krzywd. Pakt o nieagresji blokuje wypowiedzenie wojny przez obie strony przez 15 tur od odpowiedzi. Przyjęcie poprawia relacje o 5, odmowa obniża je o 5. Do tego samego państwa nowe warunki można wysłać po dziesięciu turach. Jedna rozmowa na państwo na turę obejmuje także dary i traktaty.

Odpowiedź przychodzi po dwóch turach, według sytuacji w dniu powrotu: zaufania, względnej siły armii, krzywd i wyczerpania wojną. Kharowie trudniej przyjmują warunki. Okno pokazuje bieżącą ocenę i próg 15; odszkodowanie wymaga też 80 złota w skarbcu sąsiada. Nie ma ukrytego losowania. Powrót posłów otwiera panel dyplomacji, a odpowiedź pozostaje w kronice i zapisie.

- **Podbój:** lud -8, stabilność -6, zaufanie pozostałych państw -12; ofiara otrzymuje 40 krzywd.
- **Zadośćuczynienie:** wymaga i zużywa 30 własnych krzywd; lud -2, stabilność -1, bez kary zaufania u innych państw.
- **Wyzwolenie:** dostępne, gdy sąsiad zajmuje miasto założone przez Marchie; lud -2, stabilność -1, bez kary zaufania u innych państw.

Każda wojna zrywa handel i obniża relacje z przeciwnikiem o 35. Uzasadniona wojna daje przeciwnikowi 15 krzywd. Zdobycie miasta dodaje pokonanemu 30, zniszczenie drogi 12; krzywdy maleją o 1 co osiem tur. Rozpoczęcie wojny anuluje oczekujące poselstwo. AI również podlega rozejmom, a jego agresja tworzy krzywdy i reakcję pozostałych państw.

## Wojna i cena pokoju

Przy wypowiedzeniu wojny wybierz konkretne miasto jako cel podboju lub wyzwolenia. Zadośćuczynienie zobowiązuje do uzyskania co najmniej 80 złota reparacji. Cel nie ogranicza sterowania armią, lecz jest rozliczany przy pokoju: spełniony daje inicjatorowi +12 prestiżu i +3 poparcia ludu, niespełniony -5 prestiżu (do minimum 0) i -3 poparcia. Miasto musi wtedy należeć do inicjatora; wystarczy także odzyskanie go przez traktat.

W **Przebiegu wojny** zobaczysz bilans -100…100. Miasta przeciwnika utrzymane od początku konfliktu dają po 20, utrata własnych odejmuje po 20; odzyskanie odwraca składnik. Różnica zadanych obrażeń daje maksymalnie ±25, bieżąca siła armii ±20, a względne wyczerpanie ±15. Bilans nie narzuca pokoju, lecz wpływa na ocenę warunków.

Wybierz **Negocjuj pokój**, następnie żądanie lub zapłatę 100/200 złota albo pokój bez reparacji. Opcjonalnie dodaj zwrot jednego zajętego miasta jego założycielom po dowolnej stronie konfliktu. Nie można oddać ostatniego miasta państwa. Reszta granic pozostaje pod obecną kontrolą.

Poselstwo kosztuje 20 złota. Nową propozycję można wysłać po czterech turach i zamknięciu trwających rokowań. Odpowiedź nadejdzie po dwóch turach; wojna trwa w czasie podróży. Ocena przyjęcia ma próg 50: bazowe 35, do +20 za czas wojny, +0,6 za każdy punkt wyczerpania rozmówcy, -0,8 za każdy punkt jego przewagi w bilansie wojny, relacje / 10, płatność na jego rzecz / 5 i ±30 za zwrot miasta. Interfejs pokazuje bieżący wynik; ostateczny uwzględnia sytuację przy odpowiedzi.

Płatności są wykonywane przy ratyfikacji, bez rezerwowania środków. Brak złota lub zmiana sytuacji miasta anuluje całość warunków, bez częściowej zapłaty czy transferu. Opłata podróży nie wraca. Pokojowy zwrot zachowuje zdrowie miasta, zgromadzoną produkcję i realizowany projekt.

Odrzucenie może przynieść kontrofertę. AI wysyła również własne warunki po co najmniej ośmiu turach wojny, gdy jest wyczerpana albo przegrywa. Propozycje AI podróżują dwie tury i czekają cztery kolejne tury na decyzję gracza; nie zatrzymują kończenia tur. Można je przyjąć, odrzucić lub pozostawić do wygaśnięcia. Powrót posłów i wczytanie gry kierują do dyplomacji, gdy potrzebna jest odpowiedź. AI nie narzuca graczowi automatycznego rozejmu; między sobą państwa AI mogą zawierać prosty pokój z wyczerpania.

Traktat daje 12 tur rozejmu, wyczerpanie obu stron -15 oraz krzywdy -20. Handel wymaga nowego traktatu. Wojska z terytorium drugiego sygnatariusza wycofują się do własnych miast, z ruchem 0 i anulowanym marszem; bez schronienia zostają rozwiązane. Pierwszy negocjowany pokój wywołuje dialog **Kiedy milkną miecze** o odbudowie, ofiarach i armii. Wojny i oferty pozostają w kronice oraz zapisie. Nie ma jeszcze wielostronnych konferencji, negocjacji sojuszniczych ani dowolnej wymiany terytoriów.

## Lojalność i władza lokalna

Okno **Zarządzaj** pokazuje każdy składnik celu lojalności. Lojalność zbliża się do celu o maksymalnie 3 punkty na turę. Wpływa na wydajność produkcji, złota, nauki i kultury mnożnikiem 0,85 + 0,002 × lojalność. Cel zależy od stabilności, dobrobytu, niepokojów, podatków, połączenia ze stolicą, garnizonu, miejscowych praw i podboju.

Zmiana ustroju prowincji kosztuje 40 złota i blokuje następną zmianę na osiem tur:

| Ustrój | Lojalność i gospodarka |
|---|---|
| Wspólna administracja | Pełne wpływy, bez dodatkowej premii lojalności |
| Autonomia | Cel lojalności +18, złoto ×0,70, kultura ×1,20 |
| Zarząd wojskowy | Cel +10 z garnizonem lub -12 bez niego; produkcja ×0,90, nauka ×0,80 |

Garnizonem jest piechota, łucznicy, kawaleria lub katapulta na polu miasta; zwiadowca i osadnicy nie wystarczą. Każdy garnizon dodatkowo daje +6 do celu. Przejęcie obcego miasta ustawia lojalność 30, niepokoje 55 i opór przez 12 tur, obniżający cel o 20. Obca administracja ma dalszą karę -10. Powrót do założycieli ustawia lojalność 65 i usuwa okupację.

Jeśli obce miasto kończy trzy kolejne rozliczenia polityki z lojalnością poniżej 20, wraca do państwa założycieli. Dwie pierwsze tury dają ostrzeżenia. Podniesienie lojalności do 20 zeruje licznik. Wojsko ustępującego władcy przenosi się do najbliższego własnego miasta bez obcego oddziału; bez takiego schronienia zostaje rozwiązane. Powrót miasta nie rozpoczyna sam wojny, lecz daje dotychczasowemu władcy 30 krzywd. Własne miasta mogą tracić wydajność, ale nie przechodzą do arbitralnego obcego państwa.

Dialog **Czyje prawa, czyja ziemia?** pozwala odpowiedzieć lokalnej radzie. Autonomia, zarząd wojskowy i wspólna administracja mają osobne skutki społeczne i miejscowe. AI może przyznać autonomię przy lojalności poniżej 40. Rozruchy, dialogi i zmiany ustroju pozostają w kronice.

## Sterowanie i zapisy

| Akcja | Sterowanie |
|---|---|
| Wybierz pole / oddział | LPM; przy kilku oddziałach wybierz konkretny w prawym panelu |
| Przesuń mapę | Przeciągnij LPM |
| Marsz do celu / podgląd ataku | PPM na odkrytym celu |
| Przybliżenie | Kółko myszy |
| Następny gotowy oddział | Tab |
| Centrum na stolicy | Home |
| Zakończ turę / otwórz oczekującą radę | Spacja |
| Zapisz / wczytaj | F5 / F9 |
| Zamknij okno dialogu | Esc |

Pliki `.crown` znajdują się domyślnie w `wydanie-0.10/saves/`. Format v10 przechowuje nowe warianty poselstw i wynikające z przyjętych odpowiedzi prawa tranzytu; odczytuje v1–v9. Migracja v9 zachowuje eskorty, karawany, obietnice i wcześniejsze poselstwa bez dopisywania zgód na przejazd. V9 zachowuje rozkazy eskorty i ich powiązanie z karawanami. Migracja v8 zachowuje karawany i obietnice, bez przydzielania wojska wstecz. V8 przechowuje delegacje, decyzje, terminy, wyniki i zaliczone manifesty. Migracja v7 zachowuje karawany i ich historię bez tworzenia delegacji za dawne straty. V6 zachowuje magazyny, bilanse, podatki, ceny, płatności, politykę i kontrakty, bez dopisywania wstecz karawan. Dawne dostawy pozostają wykonane. Kampanie sprzed v6 zaczynają z pustymi magazynami. V5 zachowuje wojny i rokowania. Wojny rozpoczęte wcześniej otrzymują rejestr od chwili wczytania, bez wymyślonych strat lub celów. V4 zachowuje założycieli, okupację, lojalność i poselstwa; w starszych formatach założycielem staje się obecny właściciel, a lojalność startuje od 75. V3 zachowuje potrzeby, prawa i migracje; v1/v2 otrzymują zrównoważony rozwój i dobrobyt 50. Nadpisanie starszego pliku tworzy odpowiednią kopię `.v1.bak`–`.v9.bak`. Nowe reguły zmieniają dalszy przebieg starych kampanii. `autosave.crown` jest nadpisywany; osobne zapisy pozwalają zachować poprzednie kampanie.

## Budowanie i weryfikacja

Bez zależności NuGet i bez zewnętrznego silnika gry. Potrzebny .NET SDK 10 dla Windows z pakietami referencyjnymi Windows Desktop.

```powershell
dotnet build KoronyIPogranicza.slnx -m:1 -c Release -p:MSBuildEnableWorkloadResolver=false -p:TargetPlatformDisplayName=Windows
dotnet run --project tests/Crown.Specs -c Release -p:MSBuildEnableWorkloadResolver=false
dotnet publish src/Crown.Desktop -c Release --self-contained false -o wydanie-0.10 -p:MSBuildEnableWorkloadResolver=false -p:TargetPlatformDisplayName=Windows
```

`NuGet.Config` celowo nie zawiera źródeł zewnętrznych. Parametr `TargetPlatformDisplayName` pozwala budować także w środowisku ograniczającym odczyt rejestru Windows. `Zweryfikuj.ps1` buduje, uruchamia specyfikacje silnika i testy integracji WPF. Raporty oraz rzeczywiste rendery aplikacji znajdują się w `artifacts/`.

## Architektura i dalsza produkcja

- `src/Crown.Core`: model świata, symulacja, AI, treść dialogów i serializacja; niezależne od WPF.
- `Navigation.cs`, `Movement.cs`, `Logistics.cs`, `Infrastructure.cs`, `Combat.cs`: wspólne wyszukiwanie tras, rozkazy, dostawy, gospodarka infrastruktury i model starcia z podglądem.
- `Regions.cs`, `ProvincialEvents.cs`: potrzeby i kierunki rozwoju miast, rynki regionalne, migracje oraz dialogi z lokalnymi skutkami.
- `DiplomaticCouncil.cs`, `ProvincialPolitics.cs`: poselstwa, krzywdy, uzasadnienia wojny, lojalność, ustroje i zmiany właściciela miast.
- `WarCouncil.cs`, `PeaceCouncil.cs`, `WarSaveRules.cs`: ogłoszone cele, bilans, rokowania, kontroferty, ratyfikacja i walidacja historii konfliktu.
- `Markets.cs`, `TradeActions.cs`, `MarketSaveRules.cs`, `MarketCouncil.cs`: produkcja i zużycie towarów, ceny, kontrakty, polityka handlowa, dialog oraz walidacja bilansów.
- `Caravans.cs`, `CaravanSaveRules.cs`: ruch ładunków, tranzyt, osłona, postoje, przechwytywanie i walidacja manifestów.
- `TradeCouncil.cs`, `TradeCaseSaveRules.cs`: delegacje po stratach, dynamiczne dialogi, obietnice zależne od przyjazdów i walidacja ich historii.
- `EscortOrders.cs`, `EscortSaveRules.cs`: przydziały eskorty, wspólna prognoza ruchu, rezerwacja wojska, odłączanie i walidacja rozkazów.
- `TransitCouncil.cs`, `TransitPanels.cs`: czasowe prawa przejazdu wynikające z przyjętych poselstw, diagnoza granic, ostrzeżenia i rozmowy z gospodarzem szlaku.
- `src/Crown.Desktop`: natywny interfejs WPF, rysowanie mapy, proceduralne materiały terenu i sterowanie.
- `tests/Crown.Specs`: wykonywalne specyfikacje bez bibliotek testowych; symulacje kampanii i test odtwarzalności zapisu.
- `DESIGN.md`: założenia projektu, ograniczenia i kierunek dalszych etapów.
- `CHANGELOG.md`: zmiany w aktualnym etapie produkcji.
- `ASSETS.md`: pochodzenie ilustracji AI, ścieżka i pełny prompt.

Obecna mapa jest **teksturowaną mapą 2D z umownymi budynkami i symbolami jednostek**. Realistyczna ilustracja menu nie jest obrazem rozgrywki. Pełna realistyczna oprawa 3D, animacje i udźwiękowienie pozostają do wykonania. Nie ma jeszcze flot, religii, szpiegostwa, multiplayera ani edytora treści. AI używa jawnych heurystyk; dyplomacja i symulacja społeczna wymagają rozbudowy przed pełnym wydaniem.
